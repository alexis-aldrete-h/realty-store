import "./footer.css";

function Footer(){
    return(
        <div className="footer">
            <h1> This is a footer</h1>
        </div>
    );
}

export default Footer;